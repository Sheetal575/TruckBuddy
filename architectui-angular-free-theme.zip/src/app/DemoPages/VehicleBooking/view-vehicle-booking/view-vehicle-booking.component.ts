import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-vehicle-booking',
  templateUrl: './view-vehicle-booking.component.html',
  styleUrls: ['./view-vehicle-booking.component.sass']
})
export class ViewVehicleBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
