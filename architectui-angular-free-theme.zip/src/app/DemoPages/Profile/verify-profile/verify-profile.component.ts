import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-profile',
  templateUrl: './verify-profile.component.html',
  styleUrls: ['./verify-profile.component.sass']
})
export class VerifyProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
