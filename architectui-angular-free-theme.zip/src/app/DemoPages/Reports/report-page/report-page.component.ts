import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-page',
  templateUrl: './report-page.component.html',
  styleUrls: ['./report-page.component.sass']
})
export class ReportPageComponent implements OnInit {

  heading = "Reports";
  subheading = "Here you can download all the required reports";
  icon = "pe-7s-menu icon-gradient bg-tempting-azure";

  constructor() { }

  ngOnInit() {
  }

}
