import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-reports',
  templateUrl: './view-reports.component.html',
  styleUrls: ['./view-reports.component.sass']
})
export class ViewReportsComponent implements OnInit {

  heading = "View Variours Reports";
  subheading = "Here you can download various reports";
  icon = "pe-7s-note2 icon-gradient bg-tempting-azure";

  constructor() { }

  ngOnInit() {
  }

}
