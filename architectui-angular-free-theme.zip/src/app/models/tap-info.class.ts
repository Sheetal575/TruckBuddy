import { BusinessTypeEnum } from './enums/business-type.enum';
export class TapInfo {
    id?: string;
    name?: string;
    type?: BusinessTypeEnum;
}