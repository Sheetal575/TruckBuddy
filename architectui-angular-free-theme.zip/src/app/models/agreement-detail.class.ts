export class AgreementDetails {

    startDate?: string;
    endDate?: string;
    lastRenewedOn?: string;
    referenceDocId?: string;
}