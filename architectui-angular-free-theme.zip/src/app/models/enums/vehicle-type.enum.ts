export enum VehicleTypeEnum{
    THREE_TYRE,
    FOUR_TYRE,
    SIX_TYRE,
    TEN_TYPE
}