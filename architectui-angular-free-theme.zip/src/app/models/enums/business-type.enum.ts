export enum BusinessTypeEnum {
    TAP_GENERAL,
    TAP_EXCLUSIVE,
    CLIENT
}