export enum NatureOfConsignmentEnum {
    FURNITURE,
    BEVERAGES,
    FMCG
}