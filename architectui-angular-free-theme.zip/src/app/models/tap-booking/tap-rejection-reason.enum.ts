export enum RejectionReasonsForTapEnum {
    DRIVER_UNAVAILABLE,
    VEHICLE_UNAVAILABLE,
    PAYMENT_DUE
}