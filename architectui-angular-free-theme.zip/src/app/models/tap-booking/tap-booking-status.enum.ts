export enum TapBookingStatusEnum{
    ACCEPTED,
    DECLINED, 
    AWAIT
}