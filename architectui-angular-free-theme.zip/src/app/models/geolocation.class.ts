export class GeoAddress {
    type: string = "Point";
    coordinates: number[] = [];
}
