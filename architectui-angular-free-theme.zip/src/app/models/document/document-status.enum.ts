export enum DocumentStatusEnum{
    VERIFIED,
    REJECTED,
    PENDING
}