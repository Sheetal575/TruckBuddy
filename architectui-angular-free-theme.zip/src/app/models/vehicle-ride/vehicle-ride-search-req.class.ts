import { GenericSReq } from "../../core/models/generic-search-req.class";
export class VehicleRideSRequest extends GenericSReq {}
