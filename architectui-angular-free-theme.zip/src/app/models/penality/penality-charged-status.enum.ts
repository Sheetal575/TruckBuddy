export enum PenaltyChargeStatusEnum{
    CHARGED,
    NOT_CHARGED
}