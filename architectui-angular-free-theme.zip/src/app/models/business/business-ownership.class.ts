import { DataRef } from 'src/app/core/models/dataRef.class';

export class BusinessOwnership {
    profileRef?: DataRef;
    designation?: string;
}