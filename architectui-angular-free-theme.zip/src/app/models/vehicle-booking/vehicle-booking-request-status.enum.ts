export enum VehicleBookingStatusEnum {
  ACCEPTED,
  DECLINED,
  AWAIT,
  COMPLETED,
  IN_TRANSIT,
  REJECTED,
}
