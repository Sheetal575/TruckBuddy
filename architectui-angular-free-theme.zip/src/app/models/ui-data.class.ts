export class UIData {
    logo?:       string;
    themeColor?: string;
}