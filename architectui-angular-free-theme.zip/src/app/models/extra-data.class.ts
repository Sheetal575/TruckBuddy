export class ExtraData {
    data?: string;
}