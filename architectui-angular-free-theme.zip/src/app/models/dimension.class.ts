export class Dimension {
   
    height?: number;
    width?: number;
}