export class Area {
    localArea?: string;
    city?:      string;
    state?:      string;
}
