export class OriginLocation {
    city?: string;
    state?: string;
}