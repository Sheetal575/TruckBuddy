export class PhysicalAddress {

    addressLine1?: string;
    addressLine2?: string;
    landmark?: string;
    city?: string;
    state?: string;
    zipCode?: string;
}