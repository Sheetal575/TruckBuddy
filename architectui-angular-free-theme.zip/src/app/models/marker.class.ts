export class Marker {
    lat?: number;
    lng?: number;
    label?: string;
    draggable?: boolean;
    content?: string;
    isShown?: boolean;
    icon?: string;

}
