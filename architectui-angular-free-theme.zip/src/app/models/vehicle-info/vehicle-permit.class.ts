export class VehiclePermit {

    permitId?: string;
    endDate?: string;
    documentId?: string;

}
