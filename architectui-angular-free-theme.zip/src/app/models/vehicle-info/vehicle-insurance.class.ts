export class VehicleInsurance {

    insuranceId?: string;
    endDate?: string;
    docId?: string;
}