export class ContactDetails {
  email?: string;
  mobile?: string;
  alternateNumber?: [] = [];
  keyPadOnlyMobiles?: [] = [];
}
