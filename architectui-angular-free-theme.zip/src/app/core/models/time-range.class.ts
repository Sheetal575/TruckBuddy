export class TimeRange {
  startTimeInMillis: number;
  endTimeInMillis: number;
}
