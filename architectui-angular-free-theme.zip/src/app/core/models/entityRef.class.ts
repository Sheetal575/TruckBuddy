import { DataRef } from "../../../app/core/models/dataRef.class";
export class EntityRef extends DataRef {
  extra: string;
  type: string;
}
