export class DataRef {
    id: string;
    name: string;
    extraData:string;
}
