export abstract class GenericSReq {
    isDelete: boolean;
    createdAt:string;
    modifiedAt:string;
}