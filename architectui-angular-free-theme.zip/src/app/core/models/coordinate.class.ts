export class CoOrdinate {
    long: number;
    lat:  number;
}