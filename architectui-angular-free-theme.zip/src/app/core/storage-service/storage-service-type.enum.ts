export enum StorageServiceTypeEnum {
    VEHICLE_CATEGORIES = "vehicleCategories",
    STATES = "states",
    PROFILE = "profile",
    BUSINESS_PROFILE = "businessProfile",
}
